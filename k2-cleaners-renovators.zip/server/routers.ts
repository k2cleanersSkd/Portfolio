import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { createBooking, createContactInquiry } from "./db";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  booking: router({
    submit: publicProcedure
      .input(
        z.object({
          serviceType: z.string().min(1),
          clientName: z.string().min(1),
          clientPhone: z.string().min(1),
          clientEmail: z.string().email().optional(),
          location: z.string().optional(),
          description: z.string().optional(),
          preferredDate: z.string().optional(),
          preferredTime: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const result = await createBooking({
          serviceType: input.serviceType,
          clientName: input.clientName,
          clientPhone: input.clientPhone,
          clientEmail: input.clientEmail || null,
          location: input.location || null,
          description: input.description || null,
          preferredDate: input.preferredDate || null,
          preferredTime: input.preferredTime || null,
          status: "pending",
        });

        // Notify owner of new booking
        try {
          await notifyOwner({
            title: `New Booking: ${input.serviceType}`,
            content: `Client: ${input.clientName}\nPhone: ${input.clientPhone}\nEmail: ${input.clientEmail || "N/A"}\nLocation: ${input.location || "N/A"}\nPreferred Date: ${input.preferredDate || "N/A"}\nPreferred Time: ${input.preferredTime || "N/A"}\n\nDescription: ${input.description || "N/A"}`,
          });
        } catch (error) {
          console.error("Failed to notify owner:", error);
        }

        return { success: true, message: "Booking submitted successfully" };
      }),
  }),

  contact: router({
    submit: publicProcedure
      .input(
        z.object({
          name: z.string().min(1),
          email: z.string().email(),
          phone: z.string().optional(),
          subject: z.string().min(1),
          message: z.string().min(1),
        })
      )
      .mutation(async ({ input }) => {
        const result = await createContactInquiry({
          name: input.name,
          email: input.email,
          phone: input.phone || null,
          subject: input.subject,
          message: input.message,
          status: "new",
        });

        // Notify owner of new contact inquiry
        try {
          await notifyOwner({
            title: `New Contact Inquiry: ${input.subject}`,
            content: `Name: ${input.name}\nEmail: ${input.email}\nPhone: ${input.phone || "N/A"}\n\nMessage: ${input.message}`,
          });
        } catch (error) {
          console.error("Failed to notify owner:", error);
        }

        return { success: true, message: "Contact inquiry submitted successfully" };
      }),
  }),
});

export type AppRouter = typeof appRouter;
